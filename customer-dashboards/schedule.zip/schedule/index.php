<?php require_once('db-connect.php') ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Scheduling</title>
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <link rel="stylesheet" href="./fullcalendar/lib/main.min.css">
    <script src="./js/jquery-3.6.0.min.js"></script>
    <script src="./js/bootstrap.min.js"></script>
    <script src="./fullcalendar/lib/main.min.js"></script>
    <style>
        :root {
            --bs-success-rgb: 71, 222, 152 !important;
        }

        html,
        body {
            height: 100%;
            width: 100%;
            font-family: Verdana, cursive;
        }

        .btn-info.text-light:hover,
        .btn-info.text-light:focus {
            background: #000;
        }
        table, tbody, td, tfoot, th, thead, tr {
            border-color: #ededed !important;
            border-style: solid;
            border-width: 3px !important;
            color: black;
        }
       
          /* Style the FullCalendar header */
          #calendar .fc-toolbar {
            background-color: #FFFF8F; /* Set the background color to yellow */
            color: Black; /* Set the font color to black */
          }
          .fc {
         color: black;
  }
       .fc-toolbar {
    background-color: yellow;
    color: black;
  }

  /* Set the font color for the numbers in FullCalendar to black */
  .fc-day, .fc-list-event-time {
    color: black;
  }
    </style>
</head>

<body class="bg-light">
    
    <div class="container py-5" id="page-container">
        <div class="row">
            <div class="col-md-9">
                <div id="calendar"></div>
            </div>
            <div class="col-md-3">
                <div class="cardt rounded-0 shadow" >
                    <div style="">
                        <h5 class="card-title" style="background-color: #FFFF8F; color: black; text-align: center; padding: 10px;">Schedule Form</h5>
                    </div>
                    <div class="card-body">
                        <div class="container-fluid">
                            <form action="save_schedule.php" method="post" id="schedule-form">
                                <input type="hidden" name="appointment_id" value="">
                                <div class="form-group mb-2">
                                    <label for="appointment_title" class="control-label">Title</label>
                                    <input type="text" class="form-control form-control-sm rounded-0" name="appointment_title" id="appointment_title" required>
                                </div>
                               
                                <div class="form-group mb-2">
                                    <label for="start_event_date" class="control-label">Start</label>
                                    <input type="datetime-local" class="form-control form-control-sm rounded-0" name="start_event_date" id="start_event_date" required>
                                </div>
                                <div class="form-group mb-2">
                                    <label for="end_event_date" class="control-label">End</label>
                                    <input type="datetime-local" class="form-control form-control-sm rounded-0" name="end_event_date" id="end_event_date" required>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="card-footer">
                        <div class="text-center">
                            <button class="btn btn-primary btn-sm rounded-0" type="submit" form="schedule-form" style="background-color: #FFFF8F; color: black;" ><i class="fa fa-save"></i> Save</button>
                            <button class="btn btn-default border btn-sm rounded-0" type="reset" form="schedule-form"><i class="fa fa-reset"></i> Cancel</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Event Details Modal -->
    <div class="modal fade" tabindex="-1" data-bs-backdrop="static" id="event-details-modal">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content rounded-0">
                <div class="modal-header rounded-0" style="background-color: #FFFF8F; text-align: center; ">
                    <h5  style="background-color: #FFFF8F; color: black; text-align: center; ">Schedule Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body rounded-0">
                    <div class="container-fluid">
                        <dl>
                            <dt class="text-muted">Service</dt>
                            <dd id="appointment_title" class="fw-bold fs-4"></dd>
                            <dt class="text-muted">Start</dt>
                            <dd id="start_event_date" class=""></dd>
                            <dt class="text-muted">End</dt>
                            <dd id="end_event_date" class=""></dd>
                        </dl>
                    </div>
                </div>
                <div class="modal-footer rounded-0">
                    <div class="text-end">
                        <button type="button" class="btn btn-primary btn-sm rounded-0" id="edit" data-id="">Edit</button>
                        <button type="button" class="btn btn-danger btn-sm rounded-0" id="delete" data-id="">Delete</button>
                        <button type="button" class="btn btn-secondary btn-sm rounded-0" data-bs-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Event Details Modal -->

<?php 
$schedules = $conn->query("SELECT * FROM `appointment`");
$sched_res = [];
foreach($schedules->fetch_all(MYSQLI_ASSOC) as $row){
    $row['sdate'] = date("F d, Y h:i A",strtotime($row['start_event_date']));
    $row['edate'] = date("F d, Y h:i A",strtotime($row['end_event_date']));
    $sched_res[$row['id']] = $row;
}
?>
<?php 
if(isset($conn)) $conn->close();
?>
</body>
<script>
    var scheds = $.parseJSON('<?= json_encode($sched_res) ?>')
</script>


<script>
  var calendar;
  var Calendar = FullCalendar.Calendar;
  var events = [];

  $(function() {
    if (!!scheds) {
      Object.keys(scheds).map(k => {
        var row = scheds[k]
        events.push({ id: row.id, title: row.appointment_service, start: row.start_event_date, end: row.end_event_date });
      })
    }
    var date = new Date()
    var d = date.getDate(),
      m = date.getMonth(),
      y = date.getFullYear()

    calendar = new Calendar(document.getElementById('calendar'), {
      headerToolbar: {
        left: 'prev,next today',
        right: 'dayGridMonth,dayGridWeek,list',
        center: 'title',
      },
      selectable: true,
      
      // Random default events
      events: events,
      eventClick: function(info) {
        var _details = $('#event-details-modal')
        var id = info.event.id
        if (!!scheds[id]) {
          _details.find('#appointment_title').text(scheds[id].appointment_service)
          _details.find('#start_event_date').text(scheds[id].sdate)
          _details.find('#end_event_date').text(scheds[id].edate)
          _details.find('#edit,#delete').attr('data-id', id)
          _details.modal('show')
        } else {
          alert("Event is undefined");
        }
      },
      eventDidMount: function(info) {
        // Do Something after events mounted
      },
      editable: true
    });

    calendar.render();

    // Form reset listener
    $('#schedule-form').on('reset', function() {
      $(this).find('input:hidden').val('')
      $(this).find('input:visible').first().focus()
    })

    // Edit Button
    $('#edit').click(function() {
      var id = $(this).attr('data-id')
      if (!!scheds[id]) {
        var _form = $('#schedule-form')
        console.log(String(scheds[id].start_datetime), String(scheds[id].start_datetime).replace(" ", "\\t"))
        _form.find('[name="appointment_id"]').val(id)
        _form.find('[name="appointment_title"]').val(scheds[id].appointment_service)
        _form.find('[name="start_event_date"]').val(String(scheds[id].start_event_date).replace(" ", "T"))
        _form.find('[name="end_event_date"]').val(String(scheds[id].end_event_date).replace(" ", "T"))
        $('#event-details-modal').modal('hide')
        _form.find('[name="title"]').focus()
      } else {
        alert("Event is undefined");
      }
    })

    // Delete Button / Deleting an Event
    $('#delete').click(function() {
      var id = $(this).attr('data-id')
      if (!!scheds[id]) {
        var _conf = confirm("Are you sure to delete this scheduled event?");
        if (_conf === true) {
          location.href = "./delete_schedule.php?id=" + id;
        }
      } else {
        alert("Event is undefined");
      }
    })

   
  });
</script>


</html>